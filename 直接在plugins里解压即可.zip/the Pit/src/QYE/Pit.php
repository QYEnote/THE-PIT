<?php
namespace QYE;

use Nayuki\PracticeCore;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\plugin\PluginBase;
use pocketmine\utils\TextFormat;
use pocketmine\item\Item;
use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\entity\EntityTeleportEvent;
use pocketmine\player\GameMode;
use pocketmine\player\Player;
use pocketmine\Server;
use pocketmine\event\player\PlayerChatEvent;
use pocketmine\event\player\PlayerRespawnEvent;
use pocketmine\item\ItemFactory;
use pocketmine\item\VanillaItems;
use pocketmine\inventory\Inventory;
use pocketmine\entity\effect\VanillaEffects;
use pocketmine\entity\effect\EffectInstance;
use pocketmine\item\ItemIds;
use pocketmine\event\player\PlayerDeathEvent;
use pocketmine\utils\Config;
use pocketmine\world\World;
use pocketmine\block\Block;
use pocketmine\math\Vector3;
use pocketmine\block\VanillaBlocks;
use pocketmine\block\BlockTypeIds;
use pocketmine\world\particle\ExplodeParticle;
use pocketmine\world\Position;
use pocketmine\world\particle\MobSpawnParticle;
use pocketmine\world\particle\HugeExplodeSeedParticle;
use pocketmine\scheduler\ClosureTask;

use pocketmine\event\player\PlayerItemUseEvent;
use function mt_getrandmax;
use function mt_rand;
use function sqrt;
class Pit extends PluginBase implements Listener {
    public function onEnable() : void {
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
        $this->getLogger()->info(TextFormat::GREEN . "由 QYE 开发的天坑已启动");
        $this->saveDefaultConfig();
        $config = $this->getConfig();
        $config = $this->getConfig();$WORLD = $config->getNested("ThePit.WORLD");
        $config = $this->getConfig();$HUB = $config->getNested("ThePit.HUB");
        $config = $this->getConfig();$LOBBY = $config->getNested("ThePit.LOBBY");
        $config = $this->getConfig();$PVPY = $config->getNested("ThePit.PVPY");
        $config = $this->getConfig();$JOIN = $config->getNested("ThePit.JOIN");
    }
    public function onPlayerItemUseEvent(PlayerItemUseEvent $event): void
    {

        $player = $event->getPlayer();
        $item = $event->getItem();
        $config = $this->getConfig();$LOBBY = $config->getNested("ThePit.LOBBY");
        $config = $this->getConfig();$HUB = $config->getNested("ThePit.EXIT");
        $config = $this->getConfig();$JOIN = $config->getNested("ThePit.JOIN");
        $config = $this->getConfig();$WORLD = $config->getNested("ThePit.WORLD");
        switch ($item->getCustomName()) {
            case "JOIN":

                $player->sendMessage('已加入');
                $player->teleport(Server::getInstance()->getWorldManager()->getWorldByName($WORLD)->getSafeSpawn());;
                $player->setGamemode(GameMode::ADVENTURE);
                $hub = VanillaItems::IRON_SWORD()->setCustomName("HUB");
                $player->getInventory()->setItem(8,$hub);
                $name = $player->getName();
                $this->eligibleForEquip[$name] = true;
                break;
        }
    }

    public function onJoin(PlayerJoinEvent $event) : void {


        $player = $event->getPlayer();
        $name = $player->getName();
        $config = $this->getConfig();$JOIN = $config->getNested("ThePit.JOIN");
        $config = $this->getConfig();$WORLD = $config->getNested("ThePit.WORLD");
        $player->getInventory()->clearAll();
        $config = $this->getConfig();$JOIN = $config->getNested("ThePit.JOIN");
        $join = VanillaItems::IRON_SWORD()->setCustomName("JOIN");
        $player->getInventory()->setItem(8,$join);
        $player->setGamemode(GameMode::ADVENTURE);
        $this->eligibleForEquip[$name] = true;
        $player->sendMessage(TextFormat::AQUA . "欢迎玩家" . $player->getName() . "!");
        $player->teleport(Server::getInstance()->getWorldManager()->getWorldByName($WORLD)->getSafeSpawn());

    }
    private $eligibleForEquip;
    public function onPlayerMove(PlayerMoveEvent $event): void
    {
        $player = $event->getPlayer();
        $name = $player->getName();
        $y = $player->getPosition()->getY();
        $config = $this->getConfig();$WORLD = $config->getNested("ThePit.WORLD");
        $config = $this->getConfig();
        $Y = $config->getNested("ThePit.Y");

        // 检查玩家是否首次达到Y轴40以下
        if ($player->getWorld() === Server::getInstance()->getWorldManager()->getWorldByName($WORLD)) {
            if ($y <= $Y && (!isset($this->eligibleForEquip[$name]) || $this->eligibleForEquip[$name])) {
                // 给予装备，这里以钻石剑为例
                $player->getEffects()->clear();
                $inventory = $player->getInventory();
                $player->getInventory()->clearAll();
                $bow = VanillaItems::BOW()->setCustomName("§b§l弓");
                $armorInventory = $player->getArmorInventory();
                $helmet = VanillaItems::CHAINMAIL_HELMET();
                $chestplate = VanillaItems::DIAMOND_CHESTPLATE();
                $leggings = VanillaItems::DIAMOND_LEGGINGS();
                $boots = VanillaItems::CHAINMAIL_BOOTS();
                $armorInventory->setHelmet($helmet);
                $armorInventory->setBoots($boots);
                $armorInventory->setChestplate($chestplate);
                $armorInventory->setLeggings($leggings);
                $sword = VanillaItems::IRON_SWORD();
                $inventory->addItem($sword);
                $inventory->setItem(2, VanillaItems::FISHING_ROD()->setCount(1));
                $inventory->setItem(3, $bow);
                $inventory->addItem(VanillaItems::ARROW()->setCount(1));
                $inventory->addItem(VanillaItems::GOLDEN_APPLE()->setCount(1));
                $inventory->addItem(VanillaItems::SNOWBALL()->setCount(64));
                $ef = new EffectInstance(VanillaEffects::NIGHT_VISION(), 4 * 999999, 255, false);
                $player->getEffects()->add($ef);

                // 发送消息给玩家
                // 标记此玩家已经接收过装备
                $this->eligibleForEquip[$name] = false;
                if ($player->getWorld() === Server::getInstance()->getWorldManager()->getWorldByName("hub4")) {
                    $this->eligibleForEquip[$name] = true;
                }
            }
        }
        $player = $event->getPlayer();
        $block = $player->getWorld()->getBlock($player->getPosition()->floor()->subtract(0, 1, 0));

        if ($block->getTypeId() === BlockTypeIds::SLIME) { $directionVector = $player->getDirectionVector();
            $directionVector->y = 0.8; // 调整飞行高度，避免玩家直接贴地飞行
            $player->setMotion($directionVector->multiply(3));

            // 创建爆炸粒子效果
            $particle = new HugeExplodeSeedParticle();
            $pos = $player->getPosition();
            // 对所有玩家显示粒子效果
            for ($i = 0; $i < 10; $i++) {
                $pos->getWorld()->addParticle($pos, $particle);
            }
            $WD = Server::getInstance()->getWorldManager()->getWorldByName("chaos");
            foreach ($WD->getPlayers() as $players) {
            }

        }
    }
    public function onPlayerRespawnEvent(PlayerRespawnEvent $event): void
    {
        $player = $event->getPlayer();
        $name = $player->getName();

        $world = $player->getWorld();
        $name = $player->getName();
        $config = $this->getConfig();$WORLD = $config->getNested("ThePit.WORLD");
        $config = $this->getConfig();$SPAAWN = $config->getNested("ThePit.SPAWNWORLD");
        if ($player->getWorld() === Server::getInstance()->getWorldManager()->getWorldByName($WORLD)) {
            $player->getInventory()->clearAll();
            $config = $this->getConfig();$HUB = $config->getNested("ThePit.EXIT");
            $hub = VanillaItems::IRON_SWORD()->setCustomName("HUB");
            $player->getInventory()->setItem(8,$hub);
            $this->eligibleForEquip[$name] = true;
            return;
        }
    }
    public function onDeath(PlayerDeathEvent $event) : void {
        $player = $event->getPlayer();
        $sb=VanillaItems::SNOWBALL()->setCount(16);
        $j=VanillaItems::ARROW()->setCount(5);
        $event->setDeathMessage('');
        $event->setDrops([$sb,$j]);
        $event->setXpDropAmount(0);
        $player = $event->getPlayer();
        $cause = $player->getLastDamageCause();
        $config = $this->getConfig();$WORLD = $config->getNested("ThePit.WORLD");
        if ($player->getWorld() === Server::getInstance()->getWorldManager()->getWorldByName($WORLD)) {
            $event->setDrops([]);
            $WD = Server::getInstance()->getWorldManager()->getWorldByName($WORLD);
            $event->setDeathMessage("");
            $event->getPlayer()->setGamemode(GameMode::ADVENTURE());
            $player->getInventory()->clearAll();
            $player->getArmorInventory()->clearAll();
            $player->getOffHandInventory()->clearAll();

            if ($cause instanceof EntityDamageByEntityEvent) {
                $damager = $cause->getDamager();
                if ($damager instanceof Player) {

                    $player->sendMessage("§l§cYOU DIE");
                    foreach ($WD->getPlayers() as $players) {
                        $players->sendMessage("§l[§bThe PIT§f]" . $player->getName() . " §fhas kill by " . $damager->getName() . " §f!");
                    }

                    $cause = $event->getEntity()->getLastDamageCause();
                    $damager->sendActionBarMessage("§l§o§cKILL §b" . $player->getName());
                    $WD = Server::getInstance()->getWorldManager()->getWorldByName($WORLD);
                    foreach ($WD->getPlayers() as $players) {
                    }
                    $damager->getInventory()->addItem(VanillaItems::GOLDEN_APPLE()->setCount(1));
                    $damager->setHealth($damager->getMaxHealth());
                }
            }
        }
    }
    public function onEntityDamageByEntityEvent(EntityDamageByEntityEvent $event): void
    {
        $player = $event->getEntity();
        $damager = $event->getDamager();
        $damager = $event->getDamager();
        $victim = $event->getEntity();
        $play = $damager->getName();
        $y = $damager->getPosition()->y;
        $config = $this->getConfig();$WORLD = $config->getNested("ThePit.WORLD");
        if ($damager->getWorld() === Server::getInstance()->getWorldManager()->getWorldByName($WORLD)) {
            $event->uncancel();
            if ($y >= 110) {
                $event->cancel(); // 取消事件，防止PvP
                $damager->sendMessage("PVP在下面"); // 可以根据需要更改消息
            }

            return;
        }
    }
    public function onChat(PlayerChatEvent $event): void {
        $player = $event->getPlayer();
        $message = $event->getMessage();

        if (strtolower($message) === "好玩") {
            // 给玩家一个金苹果
            $goldenApple = VanillaItems::GOLDEN_APPLE()->setCount(1);
            $player->getInventory()->addItem($goldenApple);
            $player->sendMessage("获得彩蛋金苹果");
        }
        if (strtolower($message) === "我要玩原神") {
            // 给玩家一个金苹果
            $player->sendMessage("原来你也玩原神");
        }
        if (strtolower($message) === "pit") {
            // 给玩家一个金苹果
            $player->getEffects()->clear();
            $inventory = $player->getInventory();
            $player->getInventory()->clearAll();
            $config = $this->getConfig();$WORLD = $config->getNested("ThePit.WORLD");
            $player->sendMessage("已重生");
            $player->teleport(Server::getInstance()->getWorldManager()->getWorldByName($WORLD)->getSafeSpawn());
            $name = $player->getName();
            $this->eligibleForEquip[$name] = true;
        }
    }
    public function onEntityDamageEvent(EntityDamageEvent $event): void
    {
        $entity = $event->getEntity();
        if ($entity instanceof Player) {
            switch ($event->getCause()) {
                case EntityDamageEvent::CAUSE_VOID:
                    if ($entity->getWorld() === Server::getInstance()->getWorldManager()->getDefaultWorld()) {
                        $event->cancel();
                        $entity->teleport($entity->getWorld()->getSafeSpawn());
                    } else {
                    }
                    break;
                case EntityDamageEvent::CAUSE_FALL:
                    $event->cancel();
                    break;
                case EntityDamageEvent::CAUSE_SUFFOCATION:
                    $event->cancel();
                    $entity->teleport(new Vector3($entity->getPosition()->getX(), $entity->getPosition()->getY() + 3, $entity->getPosition()->getZ()));
                    break;
            }
        }
    }
    /** @var World */
    private World $world
        /**
         * @param World $level
         */;
    public function knockBack(float $x, float $z, float $force = 0.4, ?float $verticalLimit = 0.4): void
    {
        $defaultXzKB = 0.402;
        $defaultYKb = 0.345;

        $config = $this->getConfig();$XZ = $config->getNested("PITKB.XZ");
        $config = $this->getConfig();$Y = $config->getNested("PITKB.Y");
        $config = $this->getConfig();$WORLD = $config->getNested("ThePit.WORLD");

        $arenaName = Server::getInstance()->getWorldManager()->getWorldByName($WORLD);

        switch (true) {
            case $WORLD:
                $xzKB = $XZ;
                $yKb =  $Y;;
                break;
        }

        $f = sqrt($x * $x + $z * $z);
        if ($f > 0 && mt_rand() / mt_getrandmax() > $this->knockbackResistanceAttr->getValue()) {
            $f = 1 / $f;
            $motion = clone $this->motion;
            $motion->x = ($motion->x / 2) + ($x * $f * $xzKB);
            $motion->y = ($motion->y / 2) + $yKb;
            $motion->z = ($motion->z / 2) + ($z * $f * $xzKB);
            $motion->y = min($motion->y, $yKb);
            $this->setMotion($motion);
        }
    }
}